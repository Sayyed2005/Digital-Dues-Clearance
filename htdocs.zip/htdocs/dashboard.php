<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location: login.php");
    exit();
}

$admin_name = $_SESSION['admin']; // assuming session holds username
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Student Dues</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f0f9ff;
            color: #1e293b;
            padding: 2rem 1.5rem;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dashboard-container {
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
        }

        .dashboard-card {
            background: white;
            border-radius: 28px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9f0f5;
            overflow: hidden;
        }

        .dashboard-header {
            background: linear-gradient(135deg, #e8f3fc, #ffffff);
            padding: 1.8rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e2edf7;
        }
        .dashboard-header h2 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #0b4f6c;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 0.5rem;
        }
        .dashboard-header .welcome-text {
            color: #5f7f9e;
            font-size: 0.9rem;
        }
        .dashboard-header .admin-name {
            font-weight: 600;
            color: #1e88e5;
        }

        .dashboard-actions {
            padding: 2rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .action-card {
            background: #fafdff;
            border: 1px solid #eef4fa;
            border-radius: 20px;
            padding: 1.2rem 1.5rem;
            transition: all 0.2s;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .action-card:hover {
            background: #ffffff;
            border-color: #cbdff2;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.03);
        }
        .action-icon {
            width: 48px;
            height: 48px;
            background: #eef6fc;
            border-radius: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            color: #1e88e5;
        }
        .action-content {
            flex: 1;
        }
        .action-title {
            font-weight: 700;
            font-size: 1rem;
            color: #1e374b;
            margin-bottom: 0.2rem;
        }
        .action-desc {
            font-size: 0.7rem;
            color: #6c8eae;
        }

        .logout-card {
            margin-top: 0.5rem;
            border-color: #fee2e2;
            background: #fff8f8;
        }
        .logout-card .action-icon {
            background: #fee2e2;
            color: #e25c5c;
        }
        .logout-card .action-title {
            color: #b91c1c;
        }

        footer {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.7rem;
            color: #6c8eae;
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="dashboard-card">
        <div class="dashboard-header">
            <h2><i class="fas fa-user-shield"></i> Admin Panel</h2>
            <div class="welcome-text">
                Welcome back, <span class="admin-name"><?php echo htmlspecialchars($admin_name); ?></span>
            </div>
        </div>
        <div class="dashboard-actions">
            <!-- Upload Students Link -->
            <a href="upload.php" class="action-card">
                <div class="action-icon"><i class="fas fa-upload"></i></div>
                <div class="action-content">
                    <div class="action-title">Upload Students</div>
                    <div class="action-desc">Import student data via CSV</div>
                </div>
                <i class="fas fa-chevron-right" style="color:#cbdff2;"></i>
            </a>

            <!-- Logout Link -->
            <a href="logout.php" class="action-card logout-card">
                <div class="action-icon"><i class="fas fa-sign-out-alt"></i></div>
                <div class="action-content">
                    <div class="action-title">Logout</div>
                    <div class="action-desc">End your session securely</div>
                </div>
                <i class="fas fa-chevron-right" style="color:#cbdff2;"></i>
            </a>
        </div>
    </div>
    <footer>
        <i class="fas fa-shield-alt"></i> Dues Management System — Admin Area
    </footer>
</div>
</body>
</html> 

        // Form submission to WhatsApp with pre-filled message
        document.getElementById('partnerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value.trim();
            const mobile = document.getElementById('mobile').value.trim();
            const email = document.getElementById('email').value.trim();

            const message = `I want to partner with Nexus One%0A%0AName: ${name}%0AMobile: ${mobile}%0AEmail: ${email}`;
            const whatsappURL = `https://wa.me/919082794059?text=${message}`;
            window.open(whatsappURL, '_blank');
        });

        // Smooth scroll for anchor links (optional)
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href === "#") return;
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });

       
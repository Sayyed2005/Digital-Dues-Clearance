<?php
session_start();
include "config.php";

if(!isset($_SESSION['student_id']))
{
    header("Location: student_login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

$q = "SELECT s.name, s.prn, d.*
      FROM students s
      LEFT JOIN dues d ON s.student_id = d.student_id
      WHERE s.student_id='$student_id'";

$r = mysqli_query($conn,$q);
$data = mysqli_fetch_assoc($r);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard | Dues Status</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f0f9ff;
            color: #1e293b;
            padding: 2rem 1.5rem;
            line-height: 1.5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dashboard-container {
            max-width: 800px;
            width: 100%;
            margin: 0 auto;
        }

        /* welcome card */
        .welcome-card {
            background: white;
            border-radius: 28px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9f0f5;
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .welcome-header {
            background: linear-gradient(135deg, #e8f3fc, #ffffff);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e2edf7;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .welcome-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0b4f6c;
        }
        .welcome-header h2 i {
            color: #1e88e5;
            margin-right: 8px;
        }
        .prn-badge {
            background: #eef2ff;
            padding: 0.3rem 1rem;
            border-radius: 40px;
            font-size: 0.8rem;
            font-weight: 500;
            color: #1e88e5;
        }

        .student-info {
            padding: 1rem 2rem;
            background: #fafdff;
            border-bottom: 1px solid #eef4fa;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .info-item {
            background: white;
            border-radius: 60px;
            padding: 0.4rem 1rem;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            border: 1px solid #e2edf7;
        }
        .info-item i {
            color: #4aa3d4;
        }
        .info-item span {
            font-weight: 500;
            color: #1e374b;
        }

        /* dues table */
        .dues-section {
            padding: 1.5rem 2rem;
        }
        .dues-section h3 {
            font-size: 1.2rem;
            font-weight: 600;
            color: #0b4f6c;
            margin-bottom: 1.2rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .dues-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 1px 2px rgba(0,0,0,0.02);
        }
        .dues-table th {
            text-align: left;
            padding: 0.9rem 1rem;
            background-color: #fafdff;
            border-bottom: 1px solid #e2edf7;
            font-weight: 600;
            color: #2b5c7c;
            font-size: 0.8rem;
            letter-spacing: 0.3px;
        }
        .dues-table td {
            padding: 1rem 1rem;
            border-bottom: 1px solid #eff4fa;
            vertical-align: middle;
            font-weight: 500;
        }
        .dues-table tr:last-child td {
            border-bottom: none;
        }
        .due-amount {
            font-family: monospace;
            font-size: 0.9rem;
            font-weight: 600;
            color: #1e374b;
        }
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.9rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.75rem;
            background: #fef3c7;
            color: #b45309;
        }
        .status-badge.cleared {
            background: #dcfce7;
            color: #15803d;
        }

        .logout-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: white;
            border: 1px solid #cbdff2;
            padding: 0.6rem 1.4rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.85rem;
            color: #e25c5c;
            text-decoration: none;
            transition: all 0.2s;
            margin-top: 1rem;
        }
        .logout-btn:hover {
            background: #fff0f0;
            border-color: #f3bfbf;
        }
        footer {
            text-align: center;
            margin-top: 2rem;
            font-size: 0.7rem;
            color: #6c8eae;
        }

        @media (max-width: 600px) {
            body {
                padding: 1rem;
            }
            .welcome-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .dues-table th, .dues-table td {
                padding: 0.7rem;
            }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="welcome-card">
        <div class="welcome-header">
            <h2><i class="fas fa-user-graduate"></i> Welcome, <?php echo htmlspecialchars($data['name'] ?? 'Student'); ?></h2>
            <div class="prn-badge"><i class="fas fa-id-card"></i> PRN: <?php echo htmlspecialchars($data['prn'] ?? 'N/A'); ?></div>
        </div>
        <div class="student-info">
            <div class="info-item"><i class="fas fa-envelope"></i> <span>Student ID: <?php echo htmlspecialchars($student_id); ?></span></div>
            <div class="info-item"><i class="fas fa-calendar-alt"></i> <span>Last updated: <?php echo date('d M Y'); ?></span></div>
        </div>

        <div class="dues-section">
            <h3><i class="fas fa-chart-line"></i> Dues Status</h3>
            <table class="dues-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Amount (₹)</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><i class="fas fa-book"></i> Library</td>
                        <td class="due-amount">₹ <?php echo number_format((float)($data['library_due'] ?? 0), 2); ?></td>
                        <td>
                            <?php 
                            $lib_status = $data['library_status'] ?? 'Pending';
                            $badge_class = ($lib_status == 'Approved') ? 'cleared' : '';
                            ?>
                            <span class="status-badge <?php echo $badge_class; ?>"><?php echo $lib_status; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td><i class="fas fa-flask"></i> Lab</td>
                        <td class="due-amount">₹ <?php echo number_format((float)($data['lab_due'] ?? 0), 2); ?></td>
                        <td>
                            <?php 
                            $lab_status = $data['lab_status'] ?? 'Pending';
                            $badge_class = ($lab_status == 'Approved') ? 'cleared' : '';
                            ?>
                            <span class="status-badge <?php echo $badge_class; ?>"><?php echo $lab_status; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td><i class="fas fa-coins"></i> Account</td>
                        <td class="due-amount">₹ <?php echo number_format((float)($data['account_due'] ?? 0), 2); ?></td>
                        <td>
                            <?php 
                            $acc_status = $data['account_status'] ?? 'Pending';
                            $badge_class = ($acc_status == 'Approved') ? 'cleared' : '';
                            ?>
                            <span class="status-badge <?php echo $badge_class; ?>"><?php echo $acc_status; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td><i class="fas fa-ellipsis-h"></i> Other</td>
                        <td class="due-amount">₹ <?php echo number_format((float)($data['other_due'] ?? 0), 2); ?></td>
                        <td>
                            <?php 
                            $other_status = $data['other_status'] ?? 'Pending';
                            $badge_class = ($other_status == 'Approved') ? 'cleared' : '';
                            ?>
                            <span class="status-badge <?php echo $badge_class; ?>"><?php echo $other_status; ?></span>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- Overall status row (optional but matches original table) -->
            <div style="margin-top: 1.2rem; background: #f8fafc; padding: 0.8rem 1rem; border-radius: 60px; display: flex; justify-content: space-between; align-items: center;">
                <span><strong>Overall Clearance Status</strong></span>
                <?php 
                $final_status = $data['status'] ?? 'Pending';
                $final_badge = ($final_status == 'Cleared') ? 'cleared' : '';
                ?>
                <span class="status-badge <?php echo $final_badge; ?>" style="font-size:0.8rem;"><?php echo $final_status; ?></span>
            </div>
        </div>
    </div>

    <div style="text-align: center;">
        <a href="student_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
    <footer>
        <i class="fas fa-shield-alt"></i> Student Portal — Dues Management System
    </footer>
</div>
</body>
</html>
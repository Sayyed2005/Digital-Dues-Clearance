<?php
include "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Students CSV | Dues Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f0f9ff;
            color: #1e293b;
            padding: 2rem 1.5rem;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .upload-container {
            max-width: 600px;
            width: 100%;
            margin: 0 auto;
        }

        .upload-card {
            background: white;
            border-radius: 28px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9f0f5;
            overflow: hidden;
        }

        .upload-header {
            background: linear-gradient(135deg, #e8f3fc, #ffffff);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e2edf7;
        }
        .upload-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0b4f6c;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .upload-header p {
            color: #5f7f9e;
            font-size: 0.8rem;
            margin-top: 0.25rem;
        }

        .form-body {
            padding: 1.5rem 2rem 2rem;
        }

        .input-group {
            margin-bottom: 1.5rem;
        }
        .input-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #2c5a7a;
            margin-bottom: 0.5rem;
        }
        .input-group .select-wrapper,
        .input-group .file-wrapper {
            position: relative;
        }
        .input-group i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #8bb3cf;
            font-size: 0.9rem;
            pointer-events: none;
        }
        select, input[type="file"] {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.5rem;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            border: 1.5px solid #e2edf7;
            border-radius: 48px;
            background: white;
            transition: all 0.2s;
            outline: none;
            color: #1e2f3f;
            cursor: pointer;
        }
        select {
            appearance: none;
            background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%238bb3cf' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'></polyline></svg>");
            background-repeat: no-repeat;
            background-position: right 1rem center;
        }
        select:focus, input[type="file"]:focus {
            border-color: #4aa3d4;
            box-shadow: 0 0 0 3px rgba(74, 163, 212, 0.2);
        }
        /* Style file input */
        input[type="file"] {
            padding: 0.7rem 1rem 0.7rem 2.5rem;
            cursor: pointer;
        }
        .file-name {
            font-size: 0.7rem;
            color: #6c8eae;
            margin-top: 0.3rem;
            margin-left: 0.5rem;
        }

        .btn-primary {
            width: 100%;
            background: #1e88e5;
            border: none;
            padding: 0.85rem;
            border-radius: 48px;
            font-weight: 700;
            font-size: 0.95rem;
            color: white;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-family: 'Inter', sans-serif;
            margin-top: 0.5rem;
            box-shadow: 0 4px 8px rgba(30,136,229,0.2);
        }
        .btn-primary:hover {
            background: #0f6b9e;
            transform: translateY(-2px);
            box-shadow: 0 8px 18px rgba(30,136,229,0.25);
        }

        .back-link {
            display: inline-block;
            margin-top: 1.5rem;
            text-align: center;
            width: 100%;
            color: #5f7f9e;
            text-decoration: none;
            font-size: 0.8rem;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            color: #1e88e5;
        }

        @media (max-width: 480px) {
            body {
                padding: 1rem;
            }
            .upload-header, .form-body {
                padding-left: 1.2rem;
                padding-right: 1.2rem;
            }
        }
    </style>
</head>
<body>
<div class="upload-container">
    <div class="upload-card">
        <div class="upload-header">
            <h2><i class="fas fa-upload"></i> Bulk Upload Students</h2>
            <p>Import student data via CSV file</p>
        </div>
        <div class="form-body">
            <form action="process_upload.php" method="post" enctype="multipart/form-data">
                <!-- Department -->
                <div class="input-group">
                    <label><i class="fas fa-building"></i> Department</label>
                    <div class="select-wrapper">
                        <i class="fas fa-school"></i>
                        <select name="dept" required>
                            <?php
                            $q = mysqli_query($conn,"SELECT * FROM departments");
                            while($d = mysqli_fetch_assoc($q)) {
                                echo "<option value='".$d['dept_id']."'>".htmlspecialchars($d['dept_name'])."</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <!-- Year -->
                <div class="input-group">
                    <label><i class="fas fa-calendar-alt"></i> Year</label>
                    <div class="select-wrapper">
                        <i class="fas fa-calendar"></i>
                        <select name="year" required>
                            <?php
                            $q = mysqli_query($conn,"SELECT * FROM years");
                            while($y = mysqli_fetch_assoc($q)) {
                                echo "<option value='".$y['year_id']."'>".htmlspecialchars($y['year_name'])."</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <!-- Division -->
                <div class="input-group">
                    <label><i class="fas fa-layer-group"></i> Division</label>
                    <div class="select-wrapper">
                        <i class="fas fa-columns"></i>
                        <select name="division" required>
                            <?php
                            $q = mysqli_query($conn,"SELECT * FROM divisions");
                            while($div = mysqli_fetch_assoc($q)) {
                                echo "<option value='".$div['division_id']."'>".htmlspecialchars($div['division_name'])."</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <!-- File Upload -->
                <div class="input-group">
                    <label><i class="fas fa-file-csv"></i> Upload CSV File</label>
                    <div class="file-wrapper">
                        <i class="fas fa-upload"></i>
                        <input type="file" name="file" id="csvFile" accept=".csv" required>
                    </div>
                    <div class="file-name" id="fileName">No file chosen</div>
                </div>

                <button type="submit" name="upload" class="btn-primary">
                    <i class="fas fa-cloud-upload-alt"></i> Upload Students
                </button>
            </form>
            <a href="admin_dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </div>
</div>

<script>
    // Display selected file name
    const fileInput = document.getElementById('csvFile');
    const fileNameSpan = document.getElementById('fileName');
    fileInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            fileNameSpan.textContent = this.files[0].name;
        } else {
            fileNameSpan.textContent = 'No file chosen';
        }
    });
</script>
</body>
</html>
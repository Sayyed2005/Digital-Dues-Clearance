<?php
include "config.php";

// Check if ID is provided
if(!isset($_GET['id']) || empty($_GET['id'])) {
    die("Student ID missing.");
}

$id = $_GET['id'];

// Original query (kept unchanged for functionality)
$q = mysqli_query($conn,"SELECT s.*, d.*
                         FROM students s
                         JOIN dues d ON s.student_id=d.student_id
                         WHERE s.student_id='$id'");

if(mysqli_num_rows($q) == 0) {
    die("Student not found.");
}

$data = mysqli_fetch_assoc($q);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Report | Student Dues</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f0f9ff;
            color: #1e293b;
            padding: 2rem 1.5rem;
            line-height: 1.5;
        }

        .report-container {
            max-width: 800px;
            margin: 0 auto;
        }

        /* header actions */
        .header-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .back-link {
            background: white;
            padding: 0.5rem 1.2rem;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.85rem;
            color: #0f6b9e;
            border: 1px solid #cbdff2;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .back-link:hover {
            background: #eef6fc;
            border-color: #7ab3c8;
        }
        .print-btn {
            background: white;
            border: 1px solid #cbdff2;
            padding: 0.5rem 1.2rem;
            border-radius: 40px;
            font-weight: 500;
            font-size: 0.85rem;
            color: #0f6b9e;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Inter', sans-serif;
        }
        .print-btn:hover {
            background: #eef6fc;
            border-color: #7ab3c8;
        }

        /* main card */
        .report-card {
            background: white;
            border-radius: 28px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9f0f5;
            overflow: hidden;
        }
        .report-header {
            background: linear-gradient(135deg, #e8f3fc, #ffffff);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e2edf7;
        }
        .report-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0b4f6c;
            margin-bottom: 0.25rem;
        }
        .report-header p {
            color: #5f7f9e;
            font-size: 0.8rem;
        }
        .student-info {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            margin-top: 1rem;
            background: #fafdff;
            padding: 1rem 2rem;
            border-bottom: 1px solid #eef4fa;
        }
        .info-item {
            flex: 1;
        }
        .info-label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #6c8eae;
            margin-bottom: 0.2rem;
        }
        .info-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: #1e374b;
        }
        .dues-section {
            padding: 1.5rem 2rem;
        }
        .due-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.8rem 0;
            border-bottom: 1px solid #f0f4fa;
        }
        .due-row:last-child {
            border-bottom: none;
        }
        .due-label {
            font-weight: 500;
            color: #2b5c7c;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .due-label i {
            width: 24px;
            color: #4aa3d4;
        }
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.9rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.75rem;
            background: #fef3c7;
            color: #b45309;
        }
        .status-badge.approved {
            background: #dcfce7;
            color: #15803d;
        }
        .final-status {
            background: #eef6fc;
            margin: 0 2rem 1.5rem 2rem;
            padding: 1rem;
            border-radius: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .final-label {
            font-weight: 700;
            color: #0f6b9e;
        }
        .final-value {
            font-weight: 800;
            font-size: 1.2rem;
            padding: 0.2rem 1rem;
            border-radius: 40px;
            background: white;
            color: #1e88e5;
        }
        footer {
            text-align: center;
            margin-top: 2rem;
            font-size: 0.7rem;
            color: #6c8eae;
        }

        @media print {
            body {
                background: white;
                padding: 0.5cm;
            }
            .header-bar {
                display: none;
            }
            .report-card {
                box-shadow: none;
                border: 1px solid #ccc;
            }
            .print-btn, .back-link {
                display: none;
            }
            footer {
                display: none;
            }
        }

        @media (max-width: 600px) {
            .student-info {
                flex-direction: column;
                gap: 0.8rem;
            }
            .due-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.4rem;
            }
        }
    </style>
</head>
<body>
<div class="report-container">
    <div class="header-bar">
        <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        <button class="print-btn" onclick="window.print()"><i class="fas fa-print"></i> Print Report</button>
    </div>

    <div class="report-card">
        <div class="report-header">
            <h2><i class="fas fa-clipboard-list"></i> Clearance Report</h2>
            <p>Generated on <?php echo date('F j, Y, g:i a'); ?></p>
        </div>

        <div class="student-info">
            <div class="info-item">
                <div class="info-label"><i class="fas fa-user-graduate"></i> Full Name</div>
                <div class="info-value"><?php echo htmlspecialchars($data['name']); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-id-card"></i> PRN</div>
                <div class="info-value"><?php echo htmlspecialchars($data['prn']); ?></div>
            </div>
        </div>

        <div class="dues-section">
            <!-- Library -->
            <div class="due-row">
                <div class="due-label"><i class="fas fa-book"></i> Library</div>
                <div>
                    <?php 
                    $lib_status = $data['library_status'] ?? 'Pending';
                    $lib_badge = ($lib_status == 'Approved') ? 'approved' : '';
                    ?>
                    <span class="status-badge <?php echo $lib_badge; ?>"><?php echo $lib_status; ?></span>
                </div>
            </div>
            <!-- Lab -->
            <div class="due-row">
                <div class="due-label"><i class="fas fa-flask"></i> Lab</div>
                <div>
                    <?php 
                    $lab_status = $data['lab_status'] ?? 'Pending';
                    $lab_badge = ($lab_status == 'Approved') ? 'approved' : '';
                    ?>
                    <span class="status-badge <?php echo $lab_badge; ?>"><?php echo $lab_status; ?></span>
                </div>
            </div>
            <!-- Account -->
            <div class="due-row">
                <div class="due-label"><i class="fas fa-coins"></i> Account</div>
                <div>
                    <?php 
                    $acc_status = $data['account_status'] ?? 'Pending';
                    $acc_badge = ($acc_status == 'Approved') ? 'approved' : '';
                    ?>
                    <span class="status-badge <?php echo $acc_badge; ?>"><?php echo $acc_status; ?></span>
                </div>
            </div>
        </div>

        <div class="final-status">
            <span class="final-label"><i class="fas fa-flag-checkered"></i> Final Clearance Status</span>
            <span class="final-value">
                <?php 
                $final = $data['status'] ?? 'Pending';
                echo $final;
                ?>
            </span>
        </div>
    </div>
    <footer>
        <i class="fas fa-print"></i> This report is computer generated. No signature required.
    </footer>
</div>

<script>
    // Optional: additional print customization
    console.log("Report page ready");
</script>
</body>
</html>
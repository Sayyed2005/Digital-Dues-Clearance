<?php
include "config.php";

// Check if student ID is provided
if(!isset($_GET['id']) || empty($_GET['id'])) {
    die("Student ID missing.");
}

$id = $_GET['id'];

// Fetch existing dues data
$q = mysqli_query($conn,"SELECT * FROM dues WHERE student_id='$id'");
if(mysqli_num_rows($q) == 0) {
    die("No dues record found for this student.");
}
$data = mysqli_fetch_assoc($q);

// Fetch student name for display (optional, does not affect update)
$student_query = mysqli_query($conn,"SELECT name FROM students WHERE student_id='$id'");
$student = mysqli_fetch_assoc($student_query);
$student_name = $student ? $student['name'] : 'Unknown';

if(isset($_POST['update']))
{
    $lib = $_POST['library'];
    $lab = $_POST['lab'];
    $acc = $_POST['account'];

    // Original update query preserved exactly
    mysqli_query($conn,"UPDATE dues SET 
    library_due='$lib',
    lab_due='$lab',
    account_due='$acc'
    WHERE student_id='$id'");

    header("Location: admin_dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dues | Student Dues Manager</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f0f9ff;
            color: #1e293b;
            padding: 2rem 1.5rem;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-container {
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
        }

        .form-card {
            background: white;
            border-radius: 28px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9f0f5;
            overflow: hidden;
        }

        .form-header {
            background: linear-gradient(135deg, #e8f3fc, #ffffff);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e2edf7;
        }
        .form-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0b4f6c;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-header p {
            color: #5f7f9e;
            font-size: 0.8rem;
            margin-top: 0.25rem;
        }

        .student-info {
            background: #fafdff;
            padding: 1rem 2rem;
            border-bottom: 1px solid #eef4fa;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .student-name {
            font-weight: 600;
            color: #1e88e5;
        }
        .student-id {
            font-size: 0.75rem;
            color: #6c8eae;
        }

        .form-body {
            padding: 1.5rem 2rem 2rem;
        }

        .input-group {
            margin-bottom: 1.5rem;
        }
        .input-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #2c5a7a;
            margin-bottom: 0.5rem;
        }
        .input-group .input-icon {
            position: relative;
        }
        .input-group i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #8bb3cf;
            font-size: 0.9rem;
        }
        .input-group input {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.5rem;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            border: 1.5px solid #e2edf7;
            border-radius: 48px;
            background: white;
            transition: all 0.2s;
            outline: none;
            color: #1e2f3f;
        }
        .input-group input:focus {
            border-color: #4aa3d4;
            box-shadow: 0 0 0 3px rgba(74, 163, 212, 0.2);
        }

        .button-group {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .btn-primary, .btn-secondary {
            flex: 1;
            padding: 0.8rem;
            border-radius: 48px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            text-align: center;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: none;
            font-family: 'Inter', sans-serif;
        }
        .btn-primary {
            background: #1e88e5;
            color: white;
            box-shadow: 0 4px 8px rgba(30,136,229,0.2);
        }
        .btn-primary:hover {
            background: #0f6b9e;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #f1f5f9;
            color: #2c5a7a;
            border: 1px solid #dce5ed;
        }
        .btn-secondary:hover {
            background: #e6edf4;
            transform: translateY(-1px);
        }

        @media (max-width: 480px) {
            body {
                padding: 1rem;
            }
            .form-header, .student-info, .form-body {
                padding-left: 1.2rem;
                padding-right: 1.2rem;
            }
        }
    </style>
</head>
<body>
<div class="form-container">
    <div class="form-card">
        <div class="form-header">
            <h2><i class="fas fa-edit"></i> Edit Dues</h2>
            <p>Update the due amounts for this student</p>
        </div>
        <div class="student-info">
            <span><i class="fas fa-user-graduate"></i> Student: <span class="student-name"><?php echo htmlspecialchars($student_name); ?></span></span>
            <span class="student-id"><i class="fas fa-id-badge"></i> ID: <?php echo htmlspecialchars($id); ?></span>
        </div>
        <div class="form-body">
            <form method="post">
                <div class="input-group">
                    <label><i class="fas fa-book"></i> Library Due (₹)</label>
                    <div class="input-icon">
                        <i class="fas fa-rupee-sign"></i>
                        <input type="number" name="library" step="0.01" value="<?php echo htmlspecialchars($data['library_due']); ?>" required>
                    </div>
                </div>
                <div class="input-group">
                    <label><i class="fas fa-flask"></i> Lab Due (₹)</label>
                    <div class="input-icon">
                        <i class="fas fa-rupee-sign"></i>
                        <input type="number" name="lab" step="0.01" value="<?php echo htmlspecialchars($data['lab_due']); ?>" required>
                    </div>
                </div>
                <div class="input-group">
                    <label><i class="fas fa-coins"></i> Account Due (₹)</label>
                    <div class="input-icon">
                        <i class="fas fa-rupee-sign"></i>
                        <input type="number" name="account" step="0.01" value="<?php echo htmlspecialchars($data['account_due']); ?>" required>
                    </div>
                </div>
                <div class="button-group">
                    <button type="submit" name="update" class="btn-primary"><i class="fas fa-save"></i> Update</button>
                    <a href="admin_dashboard.php" class="btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>